import osmnx as ox
import os, pickle

ox.config(use_cache=True)


def main():
    place = "Chicago"

    if not os.path.exists('tracks_sequence_of_node_' + place):
        os.mkdir('tracks_sequence_of_node_' + place)

    left, right, bottom, top = float('inf'), float('-inf'), float('inf'), float('-inf')

    for root, dirs, files in os.walk('tracks_matched_' + place):
        for file in files:
            with open(os.path.join(root, file)) as f:
                lines = f.readlines()

                for line in lines:
                    if line.strip() and line.strip() != "No-Match":
                        lat_lon_idx = line.split(',')
                        left, right = min(left, float(lat_lon_idx[1])), max(right, float(lat_lon_idx[1]))
                        bottom, top = min(bottom, float(lat_lon_idx[0])), max(top, float(lat_lon_idx[0]))

    for root, dirs, files in os.walk('tracks_OSM_' + place):
        for file in files:
            with open(os.path.join(root, file)) as f:
                lines = f.readlines()

                for line in lines:
                    if line.strip():
                        lat, lon = line.split(',')
                        left, right = min(left, float(lon)), max(right, float(lon))
                        bottom, top = min(bottom, float(lat)), max(top, float(lat))
    
    print("Downloading network from OSM with ", left, right, bottom, top, " with +- 0.2 buffer......")

    if not os.path.exists('osm_graph_' + place + '.pickle'):
        osm_road_network = ox.graph_from_bbox(north=top+0.2, south=bottom-0.2, east=right+0.2, west=left-0.2,
                                              network_type='drive', truncate_by_edge=True)

        # osm_road_network = ox.graph_from_place('New York City, New York, USA', network_type='walk', truncate_by_edge=True)

        with open('osm_graph_' + place + '.pickle', 'wb') as handle:
            pickle.dump(osm_road_network, handle)
    else:
        with open('osm_graph_' + place + '.pickle', 'rb') as handle:
            osm_road_network = pickle.load(handle)

    #G_projected = ox.project_graph(osm_road_network)
    #ox.plot_graph(G_projected)

    node_coord = dict()

    compared_coord = dict()

    for root, dirs, files in os.walk('tracks_matched_' + place):
        for file in files:
            print("Now dealing with ", file, "......")

            with open(os.path.join(root, file)) as f:
                matched_path = []

                lines = f.readlines()

                for line in lines:
                    if line.strip() == "No-Match":
                        matched_path.append(None)
                    elif line.strip():
                        lat_lon_idx = line.split(',')
                        matched_path.append((float(lat_lon_idx[0]), float(lat_lon_idx[1])))

            with open(os.path.join('tracks_OSM_' + place, file)) as gps_f:
                gps_path = []

                lines = gps_f.readlines()

                for line in lines:
                    if line.strip():
                        lat, lon = line.split(',')
                        gps_path.append((float(lat), float(lon)))

            matched_path_without_non_matched = []
            gps_path_without_non_matched = []

            for idx, val in enumerate(matched_path):
                if val is not None:
                    matched_path_without_non_matched.append(val)
                    gps_path_without_non_matched.append(gps_path[idx])

            if len(matched_path_without_non_matched):
                comparison_tuple = []

                for idx, lat_lon in enumerate(matched_path_without_non_matched):
                    print("Finishing ", idx+1, "/", len(matched_path_without_non_matched))

                    # Only keep 4 digits for efficiency
                    matched_lat, matched_lon = round(lat_lon[0], 4), round(lat_lon[1], 4)

                    if (matched_lat, matched_lon) in compared_coord:
                        matched_nearest_node = compared_coord[(matched_lat, matched_lon)]
                    else:
                        matched_nearest_node = ox.nearest_nodes(osm_road_network, matched_lon, matched_lat)
                        compared_coord[(matched_lat, matched_lon)] = matched_nearest_node

                    gps_lat = round(gps_path_without_non_matched[idx][0], 4)
                    gps_lon = round(gps_path_without_non_matched[idx][1], 4)

                    if (gps_lat, gps_lon) in compared_coord:
                        gps_nearest_node = compared_coord[(gps_lat, gps_lon)]
                    else:
                        gps_nearest_node = ox.nearest_nodes(osm_road_network, gps_lon, gps_lat)
                        compared_coord[(gps_lat, gps_lon)] = gps_nearest_node

                    #if matched_nearest_node == gps_nearest_node:
                    #    alter_fake_node = ox.nearest_nodes(osm_road_network,
                    #                                       osm_road_network.nodes[matched_nearest_node]['x'],
                    #                                       osm_road_network.nodes[matched_nearest_node]['y'])
                    #else:
                    #    alter_fake_node = None

                    comparison_tuple.append([gps_nearest_node, matched_nearest_node])

                    if matched_nearest_node != gps_nearest_node:
                        print("GPS   ", (gps_lat, gps_lon), " matched to node ", gps_nearest_node)
                        print("Match ", (matched_lat, matched_lon), " matched to node ", matched_nearest_node)
                    print("==========================")

                    if matched_nearest_node not in node_coord:
                        node_coord[matched_nearest_node] = (osm_road_network.nodes[matched_nearest_node]['y'],
                                                            osm_road_network.nodes[matched_nearest_node]['x'])

                    if gps_nearest_node not in node_coord:
                        node_coord[gps_nearest_node] = (osm_road_network.nodes[gps_nearest_node]['y'],
                                                        osm_road_network.nodes[gps_nearest_node]['x'])

                    #if alter_fake_node and alter_fake_node not in node_coord:
                    #    node_coord[alter_fake_node] = (osm_road_network.nodes[alter_fake_node]['y'],
                    #                                   osm_road_network.nodes[alter_fake_node]['x'])

                with open('tracks_sequence_of_node_' + place + '/' + str(file), 'a') as wf:
                    for r_idx, r_tuple in enumerate(comparison_tuple):
                        wf.writelines([str(r_tuple[0]), ', ', str(r_tuple[1])])
                        wf.writelines('\n')

                wf.close()

    with open('tracks_sequence_of_node_' + place + '/' + 'node_lat_lon.txt', 'a') as wf:
        for key, val in node_coord.items():
            wf.writelines([str(key), ', ', str(val[0]), ', ', str(val[1])])
            wf.writelines('\n')

    wf.close()


if __name__ == '__main__':
    main()